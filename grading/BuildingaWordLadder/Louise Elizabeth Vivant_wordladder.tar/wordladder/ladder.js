Array.prototype.contains = function(x) {
     var i = this.length;
     while (i--) {
        if (this[i] == x) {
            return true;
        }
    }
    return false;
}

Stack = function() {
  this.mystack = new Array()
}

Stack.prototype.push = function(x) {
  this.mystack.push(x)
}

Stack.prototype.pop = function(x) {
  return this.mystack.pop()
}

Stack.prototype.peek = function() {
  return this.mystack[this.mystack.length -1]
}
 
Stack.prototype.copy = function() {
   var c = this.mystack.slice(0)
   var copystack = new Stack()
   copystack.mystack = c  
   return copystack
}

Stack.prototype.reverse = function() {
   return this.mystack.reverse()
}

Stack.prototype.empty = function() {
   if (this.mystack.length == 0) {
     return true}
}

Queue = function() {
  this.myqueue = new Array()
}

Queue.prototype.enqueue = function(x) {
  this.myqueue.push(x)
}

Queue.prototype.dequeue = function(x) {
   return this.myqueue.shift() 
}

Queue.prototype.empty = function() {
   if (this.myqueue.length == 0){
      return true}
}


Set = function() {
   this.items = {}
}

Set.prototype.add = function(x) {
   if (!this.contains(x)) {
        this.items[x.toString()] = x
    }
}

Set.prototype.contains = function(x) {
     var i = this.length;
     while (i--) {
        if (this[i] == x) {
            return true;
        }
    }
    return false;
}


function main() {
   isFinal = false

   //add start word to set of used words
   currentword = startword
   usedWords = new Set()
   usedWords.add(currentword)

   // create Queue to store all the stacks of word ladders
   wordPairs = new Queue()
   firstStack = new Stack()
   firstStack.push(currentword)
   wordPairs.enqueue(firstStack)

   while (!wordPairs.empty() && !isFinal) {
      var ladder = wordPairs.dequeue()
      var topword = ladder.peek()
      if (topword == endword)
         isFinal = true
      else {
         for (var i=0;i<filehere.length; i++) {
             var candidate = filehere[i]
             if (!usedWords.contains(candidate)){
                 istrue = nextWords(topword,candidate)
                 if (istrue == true){
                    var nextStack = ladder.copy()
                    nextStack.push(candidate)
                    usedWords.add(candidate)
                    wordPairs.enqueue(nextStack)}
            }
          }
        }
      }
      if (isFinal == false){
         outputanswer("<p>" + "No answer" + "</p>")}
      if (isFinal == true){
         ladder.reverse()
         wordstring ="<table class = 'p1'>"  + "<tr><th>" + "Word Ladder:" + "</th></tr>"
         while (!ladder.empty()){
  	    currword = ladder.pop()
  	    wordstring = wordstring + "<tr><td>" + currword + "</td></tr>" }
  	 fwordstring = wordstring + "</table>"
         outputanswer(fwordstring)
      }
 return false
}
//end of main   

outputanswer = function(s){
   output = document.getElementById('wordladder')
   output.innerHTML = s
   return false
}

function validate() {
   err = {}
   startword = document.getElementById("start").value
   endword = document.getElementById("end").value
   wlength = document.getElementById("wlength").value

   if (wlength == 3) {
      filehere = threeLetterWords}
   if (wlength == 4) {
      filehere = fourLetterWords}
   if (wlength == 5) {
      filehere = fiveLetterWords}

   if(!(filehere.contains(startword))) {
      err.message = "Please enter a valid word" 
      err.field = document.getElementById("start") }
   if(!(filehere.contains(endword))) {
      err.message = "Please enter a valid word" }
   if ((startword == "") || (startword.length != wlength)) {
      err.message = "Please check your word lengths"  
      err.field = document.getElementById("start") }
   if ((endword == "") || (endword.length != wlength)) {
      err.message = "Please check your word lengths"  
      err.field = document.getElementById("end") }
   if (endword.length != startword.length) {
      err.message = "Please check your word lengths"  
      err.field = document.getElementById("end") }
   if (startword == endword) {
      err.message = "Please enter 2 words that are different"
      err.field = document.getElementById("end") }

   if (err.message) {
      alert(err.message)
      err.field.focus()}  
   if (!(err.message)) {
      main() }

}

function nextWords(topword,candidate) {
   differingLetters = []
   for (var j=0;j<wlength;j++) {
     if(topword[j] != candidate[j]) {
        differingLetters.push(candidate[j])}
   }
   if (differingLetters.length == 1) {
      return true }
   else {
      return false}
}



