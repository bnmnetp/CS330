addH2 = function(s)
{
   var newh2 = document.createElement('h2')
   newh2.innerHTML = s
   document.body.appendChild(newh2)
}

addanswer = function(s)
{
   var e=document.getElementById('answer')
   e.innerHTML = s
}

Stack = function()
{
   this.items = new Array()
}

Stack.prototype.push = function(x)
{
   this.items.push(x)
}

Stack.prototype.pop = function()
{
   return this.items.pop()
}

Stack.prototype.peek = function()
{
   return this.items[this.items.length-1]
}

Stack.prototype.empty = function()
{
   if (this.items.length == 0)
      return true
   
   else
      return false
}

Stack.prototype.copy = function()
{
   var c = this.items.slice(0)
   var copystack = new Stack()
   copystack.items = c
   return copystack
}

Stack.prototype.reverse = function()
{
   this.items.reverse()
}

Queue = function()
{
   this.myqueue = new Array() 
   
}

Queue.prototype.enqueue = function(item)
{
   this.myqueue.push(item)
}

Queue.prototype.dequeue = function(item)
{
   if (this.myqueue.length == 0)
   {
      return undefined
   }
   
   else
   {
      var ti = this.myqueue.shift()
      return ti
   }
}

Queue.prototype.empty = function()
{
   if (this.myqueue.length == 0)
      return true
   else
      return false
}

Set = function(wordlist)
{
   this.items = new Array()
   for (var i; i<this.items.length; i++)
      this.items[wordlist[i]] = false
}

Set.prototype.add = function(aword)
{
   this.items[aword] = true
}

Set.prototype.contains = function(aword)
{
   return this.items[aword]
}

differentbyone = function(word1, word2)
{
   var different = 0
   for(var l=0; l<word1.length; l=l+1)
   {
      if (word1[l] !=  word2[l])
      {
         different = different + 1
      }
   }
   if (different == 1)
   {
      return true
   }
   else
   {
       return false
   }
}

main = function()
{
   var error = false
   var wordlist = document.inputform.length.value
   var startword = document.inputform.start.value
   var endword =document.inputform.end.value
   if (wordlist == "three" && startword.length == 3 && endword.length == 3)
      var thewordlist = threeLetterWords
   else
      if (wordlist == "four" && startword.length == 4 && endword.length == 4)
         var thewordlist = fourLetterWords
      else
         if (wordlist == "five" && startword.length == 5 && endword.length == 5)
            var thewordlist =  fiveLetterWords
        else
        {
           alert("Incorrect input")
           error = true
        } 
   if (! error)
   {
      var usedset = new Set(thewordlist)
      var q = new Queue()
      var firststack = new Stack()
      firststack.push(startword)
      q.enqueue(firststack)
      var found = false
      while (! q.empty() && ! found)
      {
         var wordstack = q.dequeue()
         var topword = wordstack.peek()
         if (topword == endword)
            found = true
         else
		 {
			 for (var w=0; w<thewordlist.length; w++)
			 { 
				var testword = thewordlist[w]
				result = differentbyone(topword,testword)
				if (result == true && ! usedset.contains(testword))
				{
				   var newstack = wordstack.copy()
				   newstack.push(testword)
				   usedset.add(testword)
				   q.enqueue(newstack)
				}
			 }
		  }
	   }
	   if (found == false)
		  addanswer("<p>" + "No answer" + "</p>")
	   else
		  {
		     
			 wordstack.reverse()
			 var wordstring ="<table>"  + "<tr><th>" + "Word Ladder" + "</th></tr>"
			 while (! wordstack.empty())
			 {
				var pword = wordstack.pop()
				wordstring = wordstring + "<tr><td>" + pword + "</td></tr>"
	
			 }
			 var fwordstring = wordstring + "</table>"
			 addanswer(fwordstring)
		  }
   }
}

main2 = function()
{
   var error = false
   var wordlist = document.inputform.length.value
   var startword = document.inputform.start.value
   var endword =document.inputform.end.value
   if (wordlist == "three" && startword.length == 3 && endword.length == 3)
      var thewordlist = threeLetterWords
   else
      if (wordlist == "four" && startword.length == 4 && endword.length == 4)
         var thewordlist = fourLetterWords
      else
         if (wordlist == "five" && startword.length == 5 && endword.length == 5)
            var thewordlist =  fiveLetterWords
        else
        {
           alert("Incorrect input")
           error = true
        } 
   if (! error)
   {
      var usedset = new Set(thewordlist)
      var q = new Stack()
      var firststack = new Stack()
      firststack.push(startword)
      q.push(firststack)
      var found = false
      while (! q.empty() && ! found)
      {
         var wordstack = q.pop()
         var topword = wordstack.peek()
         if (topword == endword)
            found = true
         else
		 {
			 for (var w=0; w<thewordlist.length; w++)
			 { 
				var testword = thewordlist[w]
				result = differentbyone(topword,testword)
				if (result == true && ! usedset.contains(testword))
				{
				   var newstack = wordstack.copy()
				   newstack.push(testword)
				   usedset.add(testword)
				   q.push(newstack)
				}
			 }
		  }
	   }
	   if (found == false)
		  addanswer("<p>" + "No answer" + "</p>")
	   else
		  {
		     
			 wordstack.reverse()
			 var wordstring ="<table>"  + "<tr><th>" + "Word Ladder" + "</th></tr>"
			 while (! wordstack.empty())
			 {
				var pword = wordstack.pop()
				wordstring = wordstring + "<tr><td>" + pword + "</td></tr>"
	
			 }
			 var fwordstring = wordstring + "</table>"
			 addanswer(fwordstring)
		  }
   }
}