check = function()  {
    var start = document.getElementById("startid").value    
    var end = document.getElementById("endid").value
    var len = document.getElementById("lenid").value
    if(start.length != len)  {
      alert("Start word length not selected length")
    }
    else  {
      if(end.length != len)  {
        alert("End word length not selected length")
      }
      else  {
        submit(start,end,len)
      }
    }
}

submit = function(begin,ending,size)  {
    var start = begin
    var end = ending
    var wlength = size
    
    var theset = new Set()
    var q = new Queue()

    theset.add(start)

    if(wlength= 3)  {
      var alist = threeLetterWords
    }
    if(wlength == 4){
      alist = fourLetterWords
    }
    if(wlength == 5){
      alist = fiveLetterWords
    }
    iterate(q,theset,alist,start,end)
}    


iterate = function(theq,set,thelist,startword,endword)  {
    var q = theq
    var theset = set
    var alist = thelist
    var start = startword
    var end = endword

    for(item in alist){
      
      if(alist[item][0] == start[0] && alist[item][1] == start[1]){
        if(!(theset.contains(alist[item])==alist[item])){
          theset.add(alist[item])
          var x = new Stack()
          x.push(alist[item])
          q.enqueue(x)
        }
      else{
        if(alist[item][1] == start[1] && alist[item][2] == start[2]){
          if(!(theset.contains(alist[item])==alist[item])){
            theset.add(alist[item])
            var x = new Stack()
            q.enqueue(x)
          }
        else{
          if(alist[item][0] == start[0] && alist[item][2] == start[2]){
            if(!(theset.contains(alist[item])==alist[item])){
              theset.add(alist[item])
              var x = new Stack()
              q.enqueue(x)
            }
          }
        }
        }
      }
    }
    }   
    for(i=0;i < q.getlength(); i++)  {
      
      var stackitem = q.dequeue()
      if(stackitem.peek() == end)  {
        displaytable(stackitem)
      }
      else{
        displaytable(stackitem)
//        iterate(q,theset,alist,stackitem.peek(),end)
      }
    }
}

displaytable = function(stack)  {      
    var thestack = stack
    var table = document.getElementById('tablefield')
    while(thestack.getsize() > 0)  { 
        var rowNum = table.rows.length
        var row = table.insertRow(rowNum)
        var cell = row.insertCell(0)
        var temp = thestack.pop()
        cell.innerHTML = temp
    }
}

Stack = function() {
    this.Stack = new Array();
}

Stack.prototype.push = function(x)  {
    this.Stack.push(x);
}

Stack.prototype.pop = function()  {
    return this.Stack.pop();
}

Stack.prototype.peek = function()  {
   return this.Stack[this.Stack.length-1];
}

Stack.prototype.getsize = function()  {
   return this.Stack.length;
}

Queue = function()  {
   this.Queue = new Array();
}
/** implement queue where [0] is back of queue and [-1] is front of queue**/
Queue.prototype.enqueue = function(x)  {
    this.Queue.push(x);
}

Queue.prototype.dequeue = function()  {
    return this.Queue.pop();
}

Queue.prototype.getlength = function()  {
    return this.Queue.length;
}

Set = function()  {
    this.Set = [];
}

Set.prototype.contains = function(x)  {
    return x in this.Set;
}

Set.prototype.add = function(x)  {
    this.Set.push(x);
}
