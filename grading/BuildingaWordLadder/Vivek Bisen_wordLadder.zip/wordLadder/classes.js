function Stack()
{
    this.data = new Array()

    this.isEmpty = function()
    {
        return this.data.length == 0
    }
    this.length = function()
    {
        return this.data.length
    }
    this.toString = function()
    {
        st = "["
        for (i in this.data)
        {
            st += this.data[i]+" "
        }
        st += "]"
        return st
    }
    this.sub = function(i)
    {
        return this.data[i]
    }
    this.push = function(anItem)
    {
        this.data.push(anItem)
    }
    this.copy = function(aStack)
    {
        for (i in this.data){
            aStack.push(this.data[i])}
        return aStack
    }
    this.pop = function()
    {
        if (! this.isEmpty())
            return this.data.pop()
        return false
    }
    this.peek = function()
    {
        if (! this.isEmpty())
            return this.data[this.data.length-1]
        return false
    }
    this.clear = function()
    {
        this.data = new Array()
    }
}

function Queue()
{
    this.data = new Array()
    this.get = function()
    {
        return this.data
    }
    this.toString = function()
    {
        st = "[F> "
        for (i in this.data){
            st += this.data[i].toString()
            st += " "}
        st += "<R]"
        return st
    }
    this.isEmpty = function()
    {
        return this.data.length == 0
    }
    this.enqueue = function(item)
    {
        this.data.push(item)
    }    
    this.dequeue = function()
    {
        if (this.data)
        {
            deq = this.data[0]
            this.data = this.data.slice(1,this.data.length)
            return deq
        }
        else
            return false
    }
    this.front = function()
    {
        if (this.data)
            return this.data[0]
        else
            return false
    }
    this.last = function()
    {
        if (this.data)
            return this.data[-1]
        else
            return false
    }
    this.clear = function()
    {
        this.data = new Array()
    }
}


function Queue1()
{
    this.data = new Array()
    this.get = function()
    {
        return this.data
    }
    this.toString = function()
    {
        st = "[F> "
        for (i in this.data){
            st += this.data[i].toString()
            st += " "}
        st += "<R]"
        return st
    }
    this.isEmpty = function()
    {
        return this.data.length == 0
    }
    this.enqueue = function(item)
    {
        this.data.unshift(item)
    }    
    this.dequeue = function()
    {
        if (this.data)
        {
            deq = this.data[0]
            this.data = this.data.slice(1,this.data.length)
            return deq
        }
        else
            return false
    }
    this.front = function()
    {
        if (this.data)
            return this.data[0]
        else
            return false
    }
    this.last = function()
    {
        if (this.data)
            return this.data[-1]
        else
            return false
    }
    this.clear = function()
    {
        this.data = new Array()
    }
}

function Set()
{
    this.data = new Array()
    this.get = function()
    {
        return this.data
    }
    this.add = function(anItem)
    {
        if (! isin(this.data,anItem))
            return this.data.push(anItem)
        return {}
    }
    this.remove = function(item)
    {
        if (isin(this.data,item))
        {
            var ind = this.data.indexOf(item)
            this.data.splice(ind,1)
        }
    }
    this.size = function()
    {
        return this.data.length
    }
}
