function isin(array, object)
{
    for (index in array)
    {
        if (array[index] == object)
            return true
    }
    return false
}
function takeout(arr1, arr2)
{
    var newArr = new Array()
    for (ind1 in arr1)
    {
        if (! isin(arr2,arr1[ind1]))
            newArr.push(arr1[ind1])
        //console.log(arr1[ind1],newArr)
    }
    return newArr
}
adjWords = function(aWord, aList)
{
    aSet = new Set()
    for (index in aList)
    {
        word = aList[index]
        string = ''
        num = 0
        while (num < aWord.length)
        {
            if (aWord[num] === word[num])
                string += aWord[num]
            if (string.length >= aWord.length-1)
                aSet.add(word)
            num += 1
        }
    }
    return aSet
}

ladder = function(aWord, goal, aList)
{
    var arr = []
    var aQueue = new Queue()
    var aStack = new Stack()
    var lastStack
    //aSet  = new Set
    arr.push(aWord)
    console.log('assadafe',aWord,arr)
    aStack.push(aWord)
    aQueue.enqueue(aStack)
    console.log(aQueue.data)
    lastStack = aQueue.dequeue()
    console.log('firstlastStack',lastStack.data)
    console.log('ase',aSet)
    var i=0
    diff = takeout(adjWords(lastStack.peek(),aList).data, arr)
    console.log('diff',diff)
//    while (lastStack && lastStack.peek() != goal)
    while (i< 5)
    {
        var diff = takeout(adjWords(lastStack.peek(),aList).data, aSet)
        //console.log('b',diff)
        console.log(i,'set',aSet)
        for (ind in diff)
        {
            newStack = new Stack()
            lastStack.copy(newStack)
            newStack.push(diff[ind])
            aQueue.enqueue(newStack)
            if (! isin(aSet, diff[ind]))
                aSet.push(diff[ind])
        }
        //console.log(aQueue.data)
        lastStack = aQueue.dequeue()
        //console.log("last Stack",lastStack.data)
        //console.log('new',newStack.data)
        i+=1
    }
    if (lastStack)
    {
      console.log("The final word ladder is ")
      for (i in lastStack.data)
        console.log(lastStack.data[i])
    }
    else
      console.log("No Ladder for this combo")
}

findLadder = function()
{
    start = document.getElementById("start").value
    end = document.getElementById("end").value
    //console.log()
    console.log('adjwords' ,adjWords(start,threeLetterWords).data,'\n')
    ladder(start, end, threeLetterWords)
    //console.log(takeout([1,2,3],[1]))
    stak = new Stack()
    stak.push('a','b','c','d')
    console.log(stak.pop())
}