function isin(array, object)
{
    for (index in array)
    {
        if (array[index] == object)
            return true
    }
    return false
}
function takeout(arr1, arr2)
{
    var newArr = new Array()
    for (ind1 in arr1)
    {
        if (! isin(arr2,arr1[ind1]))
            newArr.push(arr1[ind1])
        //console.log(arr1[ind1],newArr)
    }
    return newArr
}
adjWords = function(aWord, aList)
{
    var aSet = new Set
    for (index in aList)
    {
        var word = aList[index]
        var string = ''
        var num = 0
        while (num < aWord.length)
        {
            if (aWord[num] == word[num])
                string += aWord[num]
            if (string.length >= aWord.length-1)
                aSet.add(word)
            num += 1
        }
    }
    return aSet
}

ladderS = function(aWord, goal, aList)
{
    var aQueue = new Queue()
    var aStack = new Stack()
    var lastStack
    var aSet  = new Set()
    
    aSet.add(aWord)
    aStack.push(aWord)
    aQueue.enqueue(aStack)
    lastStack = aQueue.dequeue()
    while (lastStack && lastStack.peek() != goal)
    {
        var diff = takeout(adjWords(lastStack.peek(),aList).data, aSet.data)
        for (ind in diff)
        {
            var newStack = new Stack()
            lastStack.copy(newStack)
            newStack.push(diff[ind])
            aQueue.enqueue(newStack)
            aSet.add(diff[ind])
        }
        lastStack = aQueue.dequeue()
    }
    if (lastStack)
    {
        var lad = new Array()
        for (idx in lastStack.data)
            lad.push(lastStack.data[idx])
        return lad
    }
    else
        return (["No Ladder for this combo"])
}

ladderL = function(aWord, goal, aList)
{
    var aQueue = new Queue1()
    var aStack = new Stack()
    var lastStack
    var aSet  = new Set()
    
    aSet.add(aWord)
    aStack.push(aWord)
    aQueue.enqueue(aStack)
    lastStack = aQueue.dequeue()
    while (lastStack && lastStack.peek() != goal)
    {
        var diff = takeout(adjWords(lastStack.peek(),aList).data, aSet.data)
        for (ind in diff)
        {
            var newStack = new Stack()
            lastStack.copy(newStack)
            newStack.push(diff[ind])
            aQueue.enqueue(newStack)
            aSet.add(diff[ind])
        }
        lastStack = aQueue.dequeue()
    }
    if (lastStack)
    {
        var lad = new Array()
        for (idx in lastStack.data)
            lad.push(lastStack.data[idx])
        return lad
    }
    else
        return (["No Ladder for this combo"])
}

findLadder = function()
{
    var start = document.getElementById("start").value
    var end = document.getElementById("end").value
    var size = document.getElementById("option").value
    var myBody = document.getElementById("body")
    var aTable = document.createElement('TABLE')
    
    aTable.setAttribute("border", '1')
    myBody.appendChild(aTable)

    if (start.length != end.length || start.length > 5
                                    || start.length < 3)
        alert("Please enter either 3, 4 or 5 letter words in both the boxes.")
        else
        {
        if (size == "S"){
            if (start.length == 3)
                ans = ladderS(start, end, threeLetterWords)
                else
                if (start.length == 4)
                    ans = ladderS(start, end, fourLetterWords)
                    else
                    if (start.length == 5)
                        ans = ladderS(start, end, fiveLetterWords)
        }
        if (size == "L"){
            if (start.length == 3)
                ans = ladderL(start, end, threeLetterWords)
                else
                if (start.length == 4)
                    ans = ladderL(start, end, fourLetterWords)
                    else
                    if (start.length == 5)
                        ans = ladderL(start, end, fiveLetterWords)
        }
        for (i in ans)
            {
            var tr = document.createElement("TR")
            aTable.appendChild(tr)
            var td = document.createElement('TD')
            tr.appendChild(td)
            td.appendChild(document.createTextNode(ans[ans.length-i-1]))
            td.innerHTML = ans[ans.length-i-1]
            }
        }
}