test = function() {
    var tablediv = document.getElementById("table")
    tablediv.innerHTML = ''
    document.body.appendChild(tablediv)
    var usedWords = new Set()
    var start = document.getElementById('start_element').value
    var end = document.getElementById('end_element').value
    var numletter = document.getElementById('numletter').value
    if (start.length!=numletter || end.length!=numletter) {
        tablediv.innerHTML = 'Words do not match length specified!'
        document.body.appendChild(tablediv)
    }
    else {
        usedWords.add(start)
        var queue = new Queue()
        var wordladder = false
        var queueempty = false
        var currentStack = new Stack()
        currentStack.push(start)
        while (wordladder==false && queueempty==false) {
            n = 0
            if (numletter==3) {
                for (n in threeLetterWords) {
                    var word = threeLetterWords[n]
                    if (usedWords.contains(word)==false) {
                        var diff=0
                        for(i=0; i<start.length; i++) {
                            if(start.charAt(i)!=word.charAt(i)){
                                diff++
                            }
                        } if (diff==1) {
                            var s = currentStack.clone()
                            s.push(word)
                            usedWords.add(word)
                            queue.enqueue(s)
                        } n = n + 1
                    }
                }
            }else if (numletter==4) {
                for (n in fourLetterWords) {
                    var word = fourLetterWords[n]
                    if (usedWords.contains(word)==false) {
                        var diff=0
                        for(i=0; i<start.length; i++) {
                            if(start.charAt(i)!=word.charAt(i)){
                                diff++
                            }
                        } if (diff==1) {
                            var s = currentStack.clone()
                            s.push(word)
                            usedWords.add(word)
                            queue.enqueue(s)
                        } n = n + 1
                    }
                }
            }else if (numletter==5) {
                for (n in fiveLetterWords) {
                    var word = fiveLetterWords[n]
                    if (usedWords.contains(word)==false) {
                        var diff=0
                        for(i=0; i<start.length; i++) {
                            if(start.charAt(i)!=word.charAt(i)){
                                diff++
                            }
                        } if (diff==1) {
                            var s = currentStack.clone()
                            s.push(word)
                            usedWords.add(word)
                            queue.enqueue(s)
                        } n = n + 1
                    }
                }
            }
            if (queue.isEmpty()==false) {
                currentStack = queue.dequeue()
                if (currentStack.peek()==end) {
                    var htmlstring = '<table border="2" cellpadding="6" bgcolor="#C5A96F" align="center">'
                    while (currentStack.isEmpty()==false) {
                        htmlstring += '<tr><td>'+currentStack.pop()+'</td></tr>'
                    }htmlstring += '</table>'
                    tablediv.innerHTML = htmlstring
                    document.body.appendChild(tablediv)
                    wordladder=true
                }else {
                    start = currentStack.peek()
                }
            }else {
                queueempty = true
                tablediv.innerHTML = 'No word ladder found!'
                document.body.appendChild(tablediv)
             }
        }
    }
}

var Stack = function(a) {
    if (arguments.length == 1) {
        var stack = a
    }else {
        var stack = []
    }

    this.push = function(x) {
       stack.push(x)
       return this
    }

    this.pop = function() {
       num = stack.pop()
       return num
    }

    this.peek = function() {
       return stack[stack.length-1]
    }

    this.clone = function() {
       return new Stack(stack.slice(0))
    }

    this.isEmpty = function() {
        if (stack.length==0) {
            return true
        }else {
            return false
        }
    }

}

var Queue = function() {
    var queue = []

    this.enqueue = function(x) {
       queue.push(x)
       return this
    }

    this.dequeue = function() {
       num = queue.shift()
       return num
    }

    this.isEmpty = function() {
        if (queue.length==0) {
            return true
        }else {
            return false
        }
    }
}

var Set = function() {
    var s = []

    this.add = function(x) {
       s.push(x)
       return this
    }

    this.contains = function(x) {
        n = 0
        i = 0
        for(i in s){
            if (s[n]==x){
                return true
            }
            n = n + 1
        }
        return false
    }
}