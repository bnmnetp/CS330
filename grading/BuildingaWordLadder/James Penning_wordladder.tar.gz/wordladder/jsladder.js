Check = function() {

	//clearing the table
	for(var i = document.getElementById("table").rows.length; i > 0;i--)
	{
		document.getElementById("table").deleteRow(i -1);
	}

	start = document.forms.words.start.value;
	startword = start.toLowerCase();
	
	end = document.forms.words.end.value;
	endword = end.toLowerCase();
	
	len = document.getElementById("wordlength");
	length = len.options[len.selectedIndex].value;

	if (length == 3) { wordList = threeLetterWords }
	if (length == 4) { wordList = fourLetterWords }
	if (length == 5) { wordList = fiveLetterWords }
	
	if (endword == "" || startword == "") {
		alert("Please fill in the correct forms.")
		return false 
	};
	
	if (endword.length != length || startword.length != length) {
		alert("Word size does not match the selected size.")
		return false	
	};

	if (wordList.indexOf(startword) == -1) {
		alert("There is no such start word in the dictionary.")
		return false
	};

	if (wordList.indexOf(endword) == -1) {
		alert("There is no such end word in the dictionary.")
		return false
	};

	if (startword.length == length && endword.length == length) {
		init(startword,endword,length,wordList)
	};	
	
}

init = function(start,end,len,wordList) {
	//Initializing the first stack and first queue with the starting word.
	curStack = new Stack()
	theQueue = new Queue()
	usedSet	= new Set()
	usedSet.add(start)
	curStack.push(start)
	theQueue.enqueue(curStack)

	return wordsearch(theQueue, usedSet, wordList, end, len)
}

wordsearch = function(que,used,wordList,end,len) {
	
	qStack = que.dequeue()
	currentWord = qStack.peek()
	que.enqueue(qStack)

	while (que.length() > 0 && currentWord != len) {
		
		qStack = que.dequeue()
		currentWord = qStack.peek()

		if (currentWord == end) {
			fillTable(qStack)
			return
		}
		
		que = lister(que,qStack,wordList,used)


	}
	alert("There is no solution for this combination!")
}

//returns a list of words that have one character difference
lister = function(queue,stack,wordList,set) {
	start = stack.peek()
	startSplit = start.split('')

	for (var i=0; item = wordList[i]; i++) {
		var temp = item.split('')
		var errCnt = 0
		for (var n=0; n<temp.length; n++) {
			if (temp[n] != startSplit[n]) {
				errCnt = errCnt + 1
			}
		}
		if (errCnt < 2 && set.contains(item) != true) {
			set.add(item)
			newStack = stack.dup()
			newStack.push(item)
			queue.enqueue(newStack)
		} 	
	}
		
	return queue
}

fillTable = function(stack) {
	
	var table = document.getElementById("table");
	for (var i=0; i<stack.length(); i++) {
		var row = table.insertRow(0);
		var cell = row.insertCell(0);
		cell.innerHTML = stack.Array[i];
	}
}

