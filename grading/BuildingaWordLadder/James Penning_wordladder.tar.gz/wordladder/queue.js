function Queue() {
	this.Array = Array()
}

Queue.prototype.length = function() {
	return this.Array.length
};

Queue.prototype.enqueue = function(word) {
	this.Array.unshift(word)
};

Queue.prototype.dequeue = function() {
	return this.Array.pop()
};
