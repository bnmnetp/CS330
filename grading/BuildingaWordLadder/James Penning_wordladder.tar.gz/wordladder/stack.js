function Stack(arr) {
	if (arr == undefined) {
		this.Array = Array()
	} else	{
		this.Array = Array(arr)
	}
}

Stack.prototype.length = function() {
	return this.Array.length
};

Stack.prototype.pop = function() {
	return this.Array.pop()
};

Stack.prototype.push = function(word) {
	this.Array.push(word)
};

Stack.prototype.peek = function() {
	temp = this.Array.pop()
	this.Array.push(temp)
	return temp
};

Stack.prototype.dup = function() {
	var duplicate = new Stack()
	for (var i=0;i<this.length();i++) {
		duplicate.push(this.Array[i])
	}
	return duplicate
};

Stack.prototype.reverse = function() {
	this.Array.reverse()
};
