function Set() {
	this.Array = Array()
	this.length = this.Array.length
}

Set.prototype.length = function() {
	return this.Array.length
};

Set.prototype.add = function(word) {
	this.Array.push(word)
}

Set.prototype.contains = function(word) {
    return (this.Array.indexOf(word) != -1);
}
