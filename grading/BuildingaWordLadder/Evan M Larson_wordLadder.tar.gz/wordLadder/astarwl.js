//Function for generating the table corresponding to the solution to the word ladder

genTable = function(wordStack) {
	var table = document.getElementById("ladderTable")
	//var tr = document.createElement("tr")
	//table.appendChild(tr)
	resultLength = wordStack.length()
	wordStack.reverse()
	for (var i=0;i<resultLength;i++) {
		var tr = document.createElement("tr")
		table.appendChild(tr)
		var tdIterate = document.createElement("td")
		tdIterate.innerHTML = i
		var td = document.createElement("td")
		td.innerHTML = wordStack.pop().toString()
		tr.appendChild(tdIterate)
		tr.appendChild(td)
	}
	//document.body.appendChild(table)
}

//Code found online: http://viralpatel.net/blogs/2009/03/dynamically-add-remove-rows-in-html-table-using-javascript.html
function clearTable() {
	try {
		var table = document.getElementById("ladderTable");
		var rowCount = table.rows.length;

		for(var i=0; i<rowCount; i++) {
			var row = table.rows[i];
			table.deleteRow(i);
			rowCount--;
			i--;
		}
	} catch(e) {
		alert(e);
	}
}


//Input error checking function:

check = function() {
	startWord = document.forms.myForm.startingWord.value
	startWord = startWord.toLowerCase()
	endWord = document.forms.myForm.endingWord.value
	endWord = endWord.toLowerCase()
	wordLength = document.forms.myForm.wordLength.value

	if (startWord == "" && endWord == "") {
		alert("Please pick a starting and ending word")
		return false
	}

	if (startWord.indexOf("'") != -1 || endWord.indexOf("'") != -1) {
		alert("Remember words can't contain apostrophes")
		return false
	}

	if (startWord == "") {
		alert("Please pick a starting word")
		return false
	}
	if (endWord == "") {
		alert("Please pick a starting word")
		return false
	}

	if (startWord.length == wordLength && endWord.length == wordLength) {
		init(startWord,endWord)
	}
	else {
		alert("Clearly you didn't read the directions since your word lengths don't match the size you selected")
		return false
	}
}

//Start of WordLadder.js
//Word Ladder is set up as a Breadth First Search so will always find the shortest path if one exists. Lots of memory needed though due to a potentially large branching factor.

//Look into implementing A* or some other search heuristics.

timer = new Timer()

init = function(start,end) {
	startWordStack = new Stack()
	wordLadderQueue = new PriorityQueue()
	usedWords = new Set()

	if (start == undefined && end == undefined) {
		startWord = document.forms.myForm.startingWord.value
		endWord = document.forms.myForm.endingWord.value
		wordLength = startWord.length
	}
	else {
		startWord = new Word(start,end)
		endWord = end
		wordLength = endWord.length
	}

	timer.startTimer()

	availableWordList = new Array()
	usedWords.addWord(startWord)
	startWordStack.push(startWord)
	wordLadderQueue.enqueue(startWordStack)

	if (wordLength == 3) {
		availableWordList = threeLetterWords
	}
	else if (wordLength == 4) {
		availableWordList = fourLetterWords
	}
	else {
		availableWordList = fiveLetterWords
	}

	return bestFirstwordLadder(wordLadderQueue, endWord, availableWordList, wordLength, usedWords)
}

bestFirstwordLadder = function(WLQueue, endWord, availableWordList, wordLength, usedWords) {

	//Convet Over to While Loop. Will make everything much easier, and hopefully faster/more efficent.

	nextStack = WLQueue.dequeue()
	nextWord = nextStack.peek()
	WLQueue.enqueue(nextStack)

	while (WLQueue.size() !=0 && nextWord.toString() != endWord.toString()) {

		nextStack = WLQueue.dequeue()
		nextWord = nextStack.peek()
		//console.log(nextWord.toString())

		//If the currentWord = the ending word. We are done
		if (nextWord.toString() == endWord) {
			timer.stopTimer()
			totalTime = timer.timeElapsed()
			console.log("Solution Found after " + totalTime + " seconds")

			alert("Solution Found after " + totalTime + " seconds")

			finalResult = nextStack
			resultLength = finalResult.length()
			clearTable()
			genTable(finalResult)
			return
		}

		//Creates the needed regular expressions
		regExprList = new Array()
		word = nextWord.toString()
		for (var i=0;i<wordLength;i++) {
			frontOfWord = word.substr(0,i)
			endOfWord = word.substr(i+1)
			regString = frontOfWord + "[a-z]" + endOfWord
			regExpr = new RegExp(regString)
			//console.log(regExpr)
			regExprList.push(regExpr)
		}

		WLQueue = nextWords(availableWordList, nextStack, regExprList, wordLength, WLQueue, usedWords, endWord)
	}
	timer.stopTimer()
	totalTime = timer.timeElapsed()
	console.log("Time Elapsed was " + totalTime + " seconds")
	alert("No solution Exists. Time Elapsed was " + totalTime + " seconds")
	return
}


nextWords = function(wordList, wordStack, regExprList,wordLength,wordLadderQueue, usedWords, goalWord) {
	//Goes through the wordList
	for (var i=0;i<wordList.length;i++) {
		for (var j=0;j<wordLength;j++) {
			//Checks the word against some regular expressions to see if it is one letter off from the currentWord
			matches = availableWordList[i].match(regExprList[j])
			if (matches != null) {
				//Checks to see if any words have already been used
				if (!usedWords.contains(matches[0])) {
					/*If a match exists. Clone the current stack and add the new word to it. Then push that stack onto the queue*/
					myNewStack = wordStack.clone()
					myWord = new Word(matches[0],endWord)
					myNewStack.push(myWord)
					usedWords.addWord(matches[0])
					wordLadderQueue.enqueue(myNewStack)
				}
			}
		}
	}
	return wordLadderQueue
}



