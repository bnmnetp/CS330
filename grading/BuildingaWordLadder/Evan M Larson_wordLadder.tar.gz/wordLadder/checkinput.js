//Function for checking if the word ladder was filled out properly.

checkInput = function() {
	startWord = document.forms.myForm.startingWord.value
	endWord = document.forms.myForm.endingWord.value
	wordLength = document.forms.myForm.wordLength.value

	if (startWord == "" && endWord == "") {
		alert("Please pick a starting and ending word")
		return false
	}

	if (startWord == "") {
		alert("Please pick a starting word")
		return false
	}
	if (endWord == "") {
		alert("Please pick a starting word")
		return false
	}

	if (startWord.length == wordLength && endWord.length == wordLength) {
		return true
	}
	alert("Clearly you didn't read the directions since your word lengths don't match the size you selected")
	return false
}
