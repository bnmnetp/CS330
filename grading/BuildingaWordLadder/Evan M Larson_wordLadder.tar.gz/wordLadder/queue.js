//Queue Class

Queue = function() {
	var queue = new Array()
	
	this.enqueue = function(thingToPush) {
		queue.push(thingToPush)
	}

	this.dequeue = function() {
		if (queue.length != 0) {
			return queue.shift()
		}
		else {
			console.log("Queue is Empty")
		}
	}

	this.peek = function() {
		if (Queue.length != 0) {
			return queue[0]
		}
	}

	this.length = function() {
		return queue.length
	}
}
