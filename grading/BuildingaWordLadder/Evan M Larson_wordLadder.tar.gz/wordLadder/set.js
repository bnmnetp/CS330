//Set Class

Set = function() {
	
	this.addWord = function(wordToAdd) {
		this[wordToAdd] = 1
	}

	this.contains = function(questionableWord) {
		return questionableWord in this
	}

	this.sizeOfSet = function() {
		numElements = 0
		for (var key in this) {
			numElements++
		}
		return (numElements - 3)
	}
}

