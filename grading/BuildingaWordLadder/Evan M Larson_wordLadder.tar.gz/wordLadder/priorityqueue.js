/*    #Heap(lst) - Create a heap from the list, lst, of ordered elements. The lst value defaults to the empty list.
    #insert(element) - element is an ordered element that will be inserted according to its ordering with the other elements of the heap.
    #delMin() - deletes and returns the minimum priority element from the heap.
    #size() - returns the number of elements in the heap.
    #peek() - returns the next element that delMin will return when called. The size of the heap must be greater than 0 to call this function, otherwise an error will occur.
*/
 
PriorityQueue = function() {
	var heap = new Heap()
        
	this.enqueue = function(value) {
        	heap.insert(value)
	}
        
	this.dequeue = function() {
        	if (this.isEmpty()) {
            		console.log("Can't Dequeue from an empty Queue")
		}
        	else {
            		return heap.delMin()
		}
	}
    
	this.isEmpty = function() {
        	return heap.size() == 0
	}
    
	this.peek = function() {
        	if (heap.size() > 0) {
            		return heap.peek()
		}
	}
        
	this.size = function() {
        	return heap.size()
	}
}
