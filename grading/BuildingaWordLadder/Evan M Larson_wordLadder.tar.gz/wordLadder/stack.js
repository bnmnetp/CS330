//Stack Class

Stack = function(newArray) {
	if (newArray == undefined) {
		var stack = new Array()
	}
	else {
		var stack = newArray
	}
	

	this.push = function(thingToPush) {
		stack.push(thingToPush)
	}

	this.pop = function() {
		if (stack.length != 0) {
			return stack.pop()
		}
		else {
			console.log("Stack is Empty")
		}
	}

	this.peek = function() {
		if (stack.length != 0) {
			return stack[stack.length-1]
		}
	}

	this.length = function() {
		return stack.length
	}

	this.clone = function() {
		var clone = new Array()
		for (var i=0;i<stack.length;i++) {
			clone.push(stack[i])
		}
		cloneStack = new Stack(clone)
		return cloneStack
	}

	this.reverse = function() {
		stack = stack.reverse()
	}

	this.closestWord = function() {
		return (this.peek().intRep() + this.length())
	}
}

