//Function for generating the table corresponding to the solution to the word ladder

generateTable = function(wordStack) {
	var table = document.getElementById("ladderTable")
	var tr = document.createElement("tr")
	table.appendChild(tr)
	resultLength = wordStack.length()
	wordStack.reverse()
	for (var i=0;i<resultLength;i++) {
		var tr = document.createElement("tr")
		table.appendChild(tr)
		var td = document.createElement("td")
		td.innerHTML = wordStack.pop()
		tr.appendChild(td)
	}
	//document.body.appendChild(table)
}

//Code found online: http://viralpatel.net/blogs/2009/03/dynamically-add-remove-rows-in-html-table-using-javascript.html
function clearTable() {
	try {
		var table = document.getElementById("ladderTable");
		var rowCount = table.rows.length;

		for(var i=0; i<rowCount; i++) {
			var row = table.rows[i];
			table.deleteRow(i);
			rowCount--;
			i--;
		}
	} catch(e) {
		alert(e);
	}
}
