//Heap implementation. Needed for latter implementing a Priority Queue

Heap = function() {
	var heapList = new Array()
	heapList.push(0)
	var currentSize = 0

	var percUp = function(i) {
		while (Math.floor(i/2) > 0) {
			parentNode = Math.floor(i/2)
            		if (heapList[i].closestWord() < heapList[parentNode].closestWord()) {
				tmp = heapList[parentNode]
				heapList[parentNode] = heapList[i]
				heapList[i] = tmp
			}
            		i = Math.floor(i/2)
		}
	}

	var percDown = function(i) {
		while ((2*i) <= currentSize) {
			mc = minChild(i)
			if (heapList[i].closestWord() > heapList[mc].closestWord()) {
				//if value at node is greater than that of the "min child" swap them
				tmp = heapList[i]
				heapList[i] = heapList[mc]
				heapList[mc] = tmp
			}
		i = mc
		}
	}

	var minChild = function(i) {
		if ((2*i)+1 > currentSize) {
			return (2*i)
		}
		else {
			if (heapList[2*i].closestWord() < heapList[(2*i)+1].closestWord()) {
				return (i*2)
			}
			else {
				return ((2*i)+1)
			}
		}
	}

	this.delMin = function() {
		retval = heapList[1]
		heapList[1] = heapList[currentSize]
		currentSize--
		heapList.pop()
		percDown(1)
		return retval
	}

	this.insert = function(item) {
		heapList.push(item)
		currentSize++
		percUp(currentSize)
	}

	this.size = function() {
		return currentSize
	}

	this.peek = function() {
		if (heapList.length > 0) {
			return heapList[1]
		}
		else {
			console.log("Heap is Empty")
		}
	}

}
