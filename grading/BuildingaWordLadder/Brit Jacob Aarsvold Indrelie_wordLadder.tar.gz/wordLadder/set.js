Set = function() {
    
    this.addWord = function(word) {
        this[word] = 1
    }

    this.contains = function(word) {
        return word in this
    }

}
