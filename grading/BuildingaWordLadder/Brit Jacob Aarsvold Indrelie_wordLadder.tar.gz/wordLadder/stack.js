Stack = function(newArray) {
    if (newArray == undefined) {
        var s = new Array()
    }
    else {
        var s = newArray
    }
    

    this.push = function(x) {
        s.push(x)
    }

    this.pop = function() {
        if (s.length != 0) {
            return s.pop()
        }
        else {
            console.log("s is Empty")
        }
    }

    this.peek = function() {
        if (s.length != 0) {
            return s[s.length-1]
        }
    }

    this.length = function() {
        return s.length
    }

    this.clone = function() {
        var clone = new Array()
        for (var i=0;i<s.length;i++) {
            clone.push(s[i])
        }
        clones = new Stack(clone)
        return clones
    }

}
