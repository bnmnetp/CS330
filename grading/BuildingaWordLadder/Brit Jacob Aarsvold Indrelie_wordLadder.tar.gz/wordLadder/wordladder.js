start = function() {
    start = document.forms.myForm.startingWord.value
    end = document.forms.myForm.endingWord.value
    len = document.forms.myForm.wordLength.value

    if (end.length == len && start.length == len) {
        run(start,end)
    }
    else {
        alert("Words not entered correctly or invalid, reload and try again")
        return false
    }
}

run = function(s,e) {
    start = s
    end = e
    startstack = new Stack()
    q = new Queue()
    used = new Set()
    wordLength = start.length

    unused = new Array()
    used.addWord(start)
    startstack.push(start)
    q.enqueue(startstack)

    if (wordLength == 3) {
        unused = threeLetterWords
    }
    else if (wordLength == 4) {
        unused = fourLetterWords
    }
    else {
        unused = fiveLetterWords
    }

    nextstack = q.dequeue()
    nextword = nextstack.peek()
    q.enqueue(nextstack)

    while (q.length() !=0 && nextword != end) {

        nextstack = q.dequeue()
        nextword = nextstack.peek()

        if (nextword == end) {
            result = nextstack
            resultLength = result.length()
            clear()
            maketable(result)
            return
        }
        regExprList = new Array()
        for (var i=0;i<wordLength;i++) {
            frontOfWord = nextword.substr(0,i)
            endOfWord = nextword.substr(i+1)
            regString = frontOfWord + "[a-z]" + endOfWord
            regExpr = new RegExp(regString)
            regExprList.push(regExpr)
        }

        for (var i=0;i<unused.length;i++) {
            for (var j=0;j<wordLength;j++) {
            	matches = unused[i].match(regExprList[j])
            	if (matches != null) {
                    if (!used.contains(matches[0])) {
                    	newstack = nextstack.clone()
                    	newstack.push(matches[0])
                    	used.addWord(matches[0])
                    	q.enqueue(newstack)
                    }
            	}
            }
    	}
    }
    alert("Solution not found")
    return
}

maketable = function(wstack) {
    var table = document.getElementById("table")
    resultLength = wstack.length()
    for (var i=0;i<resultLength;i++) {
        var tr = document.createElement("tr")
        table.appendChild(tr)
        var td = document.createElement("td")
        td.innerHTML = wstack.pop()
        tr.appendChild(td)
    }
}

function clear() {
    try {
        var table = document.getElementById("table");
        var rowCount = table.rows.length;

        for(var i=0; i<rowCount; i++) {
            var row = table.rows[i];
            table.deleteRow(i);
            rowCount--;
            i--;
        }
    } catch(e) {
        alert(e);
    }
}
