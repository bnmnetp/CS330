Queue = function() {
    var q = new Array()
    
    this.length = function() {
        return q.length
    }
    
    this.enqueue = function(item) {
        q.push(item)
    }

    this.dequeue = function() {
        if (q.length != 0) {
            return q.shift()
        }
        else {
            console.log("queue is empty")
        }
    }

    this.peek = function() {
        if (Queue.length != 0) {
            return q[0]
        }
    }
}

