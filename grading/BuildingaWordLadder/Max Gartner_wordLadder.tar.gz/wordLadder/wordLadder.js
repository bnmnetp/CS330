test = function () {

    document.write(oneLetterDifferent("bat", [], threeLetterWords))


}

Stack = function () {
    pop = function () {
        return this.stack.pop()
    }
    push = function (num) {
        this.stack.push(num)
    }
    peek = function () {
        var temp = this.stack.pop()
        this.stack.push(temp)
        return temp
    }
    clone = function () {
        cloneStack = new Stack()
        for (key in this.stack) {
            cloneStack.push(this.stack[key])
        }
        return cloneStack
    }
    isEmpty = function () {
        return this.stack.length == 0
    }
    this.stack = new Array()
    this.pop = pop
    this.push = push
    this.peek = peek
    this.clone = clone
    this.isEmpty = isEmpty
}

Queue = function () {
    enqueue = function (item) {
        this.queue.push(item)
    }
    dequeue = function () {
        return this.queue.shift()
    }
    isEmpty = function () {
        return this.queue.length == 0
    }
    this.queue = new Array()
    this.enqueue = enqueue
    this.dequeue = dequeue
    this.isEmpty = isEmpty
}

Set = function () {
    add = function (item) {
        this.set.push(item)
    }
    contains = function (item) {
        var contained
        if ( this.set.indexOf(item) >= 0 ) {
            contained = true
        } else {
            contained = false
        }
        return contained
    }
    this.set = new Array()
    this.add = add
    this.contains = contains
}

oneLetterDifferent = function (currentWord, usedWords, selectWords) {
    var letterArray = currentWord.split("")
    var possibleWords = new Array()

    for (key in selectWords) {
        var differences = 0
        var wordLen = currentWord.length - 1
        var word = selectWords[key]

        while (wordLen >= 0) {
            if (word[wordLen] != currentWord[wordLen] && !usedWords.contains(word)) {
                differences = differences + 1
            }
            wordLen = wordLen - 1
        }
        if (differences == 1) {
            possibleWords.push(word)
        }
    }
    return possibleWords
}

wordLadderRecursion = function (stackQueue, usedWords, endWord, selectWords) {
    if (stackQueue.isEmpty()) {
        return null
    } 
    else {
        var currentStack = stackQueue.dequeue()
        var topWord = currentStack.peek()
        if (topWord == endWord) {
            return currentStack
        } else {
            var possibleWords = oneLetterDifferent(topWord, usedWords, selectWords)
    
            for (key in possibleWords) {
                var temp = possibleWords[key]
                var newStack = currentStack.clone()
                newStack.push(temp)
                usedWords.add(temp)
                stackQueue.enqueue(newStack)
            }

         return wordLadderRecursion(stackQueue, usedWords, endWord, selectWords)
        }
    }

}


wordLadder = function () {
    var start = document.getElementById("start").value
    var end = document.getElementById("end").value
    var wordLen = start.length

    if ( wordLen != end.length || wordLen > 5 || wordLen < 3 || start == end ) {
        alert("Word problems!")
    }
    else {
        if (wordLen == 3) {
            var selectWords = threeLetterWords
        }
        if (wordLen == 4) {
            var selectWords = fourLetterWords
        }
        if (wordLen == 5) {
            var selectWords = fiveLetterWords
        }
        var usedWords = new Set()
        usedWords.add(start)
        //Step One: Get the starting word and search through the dictionary to find
        //all the words that are one letter different and have not been used.
        var possibleWords = oneLetterDifferent(start, usedWords, selectWords)
        var stackQueue = new Queue()
        //Step Two: Create stacks for each different word, then add the starting word
        //and the word with one different letter, add the different words to a set
        //of used words 
        for (key in possibleWords) {
            var newStack = new Stack()

            newStack.push(start)
            newStack.push(possibleWords[key])
            usedWords.add(possibleWords[key])
            //Step Three: Add each stack onto a queue of stacks
            stackQueue.enqueue(newStack)
        }

        //Step Four: Dequeue first stack and rerun algoritm on it, this method
        //is recursive and it returns the first stack to match the end word
        var result = wordLadderRecursion(stackQueue, usedWords, end, selectWords)

        if (result == null) {
            alert("There is no match")
        } else {
            result.stack = result.stack.reverse()
            var tablediv = document.getElementById("tablediv")
            var table = document.createElement("table")
            var tableBody = document.createElement("tbody")
            while (!result.isEmpty()) {
                var word = document.createTextNode(result.pop())
                var cell = document.createElement("td").appendChild(word)
                var row = document.createElement("tr")
                row.appendChild(cell)
                tableBody.appendChild(row)
            }
            table.appendChild(tableBody)
            tablediv.appendChild(table)
        }
    }
}

