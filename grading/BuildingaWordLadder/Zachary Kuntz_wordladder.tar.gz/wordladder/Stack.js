//****stack implementation******

function Stack(arr) {
	if (arr == undefined) {
		this.Array = Array()
	} else	{
		this.Array = Array(arr)
	}
	this.length = this.Array.length
}

Stack.prototype.getLength = function() {
	return this.Array.length
};

Stack.prototype.pop = function() {
	return this.Array.pop()
};

Stack.prototype.push = function(word) {
	this.Array.push(word)
};

Stack.prototype.peek = function() {
	temp = this.Array.pop()
	this.Array.push(temp)
	return temp
};

Stack.prototype.clone = function() {
	var clone = new Stack()
	for (var i=0;i<this.getLength();i++) {
		clone.push(this.Array[i])
	}
	return clone
};

Stack.prototype.reverse = function() {
	this.Array.reverse()
};

//****queue implementation*****


function Queue() {
	this.Array = Array()
	this.length = this.Array.length
}

Queue.prototype.getLength = function() {
	return this.Array.length
};

Queue.prototype.enqueue = function(word) {
	this.Array.unshift(word)
};

Queue.prototype.dequeue = function() {
	return this.Array.pop()
};


//*****set implementation*******


function Set() {
	this.Array = Array()
	this.length = this.Array.length
}

Set.prototype.add = function(word) {
	this.Array.push(word)
}


Set.prototype.contains = function(word) {
	if (this.Array.indexOf(word) != -1) {
		return true;
	}
	else{
		return false;
	}
}




//******table*****

fillTable = function(stack) {
	var table = document.getElementById("mytable");
	for (i=0;i < stack.getLength(); i++) {
		var row = table.insertRow(0);
		var cell = row.insertCell(0);
		cell.innerHTML = stack.Array[i];
	}
}

function clearTable() {
	for(var i = document.getElementById("mytable").rows.length; i > 0;i--)
	{
		document.getElementById("mytable").deleteRow(i -1);
	}
}
