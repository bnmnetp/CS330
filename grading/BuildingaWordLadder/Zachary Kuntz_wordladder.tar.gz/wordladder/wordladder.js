//****code to ensure words inputed are correct****

Check = function() {
first = document.forms.wordform.first.value
firstword = first.toLowerCase()
last = document.forms.wordform.last.value
lastword = last.toLowerCase()
e = document.getElementById("length")
length = e.options[e.selectedIndex].value

if (firstword == "" || lastword == "") {
	alert("You are missing your first or last word. Enter one please.")
	return false }

if (firstword.length != length || lastword.length != length){
	alert("Selected size and word size do not match.")
	return false }

begin = new Stack()
begin.push(firstword)
search(begin, lastword, length)
}


//****searching algorithm****



children = function(stack,wordlist,visited,queue) {
	word = stack.peek()
	temp = word.split('')


	for (var i=0;item = wordlist[i]; i++) {
		var error = 0
		temp2 = item.split('') 
		for (var n=0; n < length;n++) {
			if (temp[n] != temp2[n]) {
				error += 1 
				if (error > 1) { n = 99}
			}
		}
		if (error < 2 && visited.contains(item) == false) {
				childlist = stack.clone()
				childlist.push(item)
				queue.enqueue(childlist)
		}
		
	}
return queue;
}

search = function(currentstack,goal,length) {

	if (length == 3) { wordlist = threeLetterWords }
	if (length == 4) { wordlist = fourLetterWords }
	if (length == 5) { wordlist = fiveLetterWords }
	wordqueue = new Queue()
	visited = new Set()
	timer = new Timer()
	timer.startTimer()
	wordqueue.enqueue(currentstack)
	
	while(wordqueue.getLength() > 0){
		currentstack = wordqueue.dequeue()
		curword = currentstack.peek()

		if (visited.contains(curword) == false) {

			visited.add(curword)
			
			if (curword == goal){
				timer.stopTimer()
				time = timer.timeElapsed()
				alert("done :) solved in " + time + "sec")
				currentstack.reverse()
				clearTable()
				fillTable(currentstack)
				return;
			}

			wordqueue = children(currentstack,wordlist,visited,wordqueue)

		}
		
	}
	timer.stopTimer()
	time = timer.timeElapsed()
	alert("done with no solution in " + time + " sec :(")
	return;
			

}
