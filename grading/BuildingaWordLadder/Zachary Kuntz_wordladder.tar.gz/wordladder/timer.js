Timer = function() {
	var startTime = 0
	var endTime = 0

	this.startTimer = function() {
		startTime = Date.now()
	}

	this.stopTimer = function() {
		endTime = Date.now()
	}

	this.timeElapsed = function() {
		return ((endTime-startTime)/1000)
	}


}
