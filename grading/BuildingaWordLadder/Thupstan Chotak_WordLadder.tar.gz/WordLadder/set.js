Set = function(){
	this.set = new Array()
}

Set.prototype.add = function(x){
	if (!this.contains(x)){
		this.set.push(x)
	}
}

Set.prototype.remove = function(x){
	var index = this.set.indexOf(x)
	if (index >= 0){
		return this.set.splice(index, 1)
	}
}

Set.prototype.isEmpty = function(){
	if (this.set == []){
		return true
	} else return false
}

Set.prototype.contains = function(e) {
    for(x in this.set)
        if(this.set[x] === e)
            return true;
    return false;
}

s = new Set()
s.add(5)
s.add(25)
s.add(26)
s.add(5)
s.add(69)
console.log(s)
s.remove(26)
console.log(s)
