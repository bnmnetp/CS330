adjacent = function(word, list){
	alphabets = ['a','b','c','d', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
	adjList = []
	if (contains(word, list)){
		for (i in word){
			for (a in alphabets){
				newStr = word.slice(0, i) + alphabets[a] + word.slice(Number(i)+1)
				if (contains(newStr, list) && newStr !== word){
					adjList.push(newStr)
				}
			}
		}			
	}
	return adjList
}

contains = function(word, list) {
    for(x in list)
        if(list[x] === word)
            return true;
    return false;
}

buildLadder = function(numOfLetters, startWord, endWord){
	if (numOfLetters == 3){
		var list = threeLetterWords
	} else if (numOfLetters == 4){
		list = fourLetterWords
	} else if (numOfLetters == 5){
		list = fiveLetterWords
	}
	if (contains(startWord, list) && contains(endWord, list)){
		var q = new Queue()
		var s = new Stack()
		var set = new Set()
		s.push(startWord)
		set.add(startWord)
		q.enqueue(s)
		while (!q.isEmpty()){
			var topStack = q.dequeue()
			var topWord = topStack.peek()
			adjList = adjacent(topWord, list)
			if (adjList != []){
				for (x in adjList){
					var word = adjList[x]
					if (word !== endWord){
						if (!set.contains(word)){
							var newStack
							newStack = topStack.deepcopy()
							newStack.push(word)
							set.add(word)
							q.enqueue(newStack)
						}
					} else {
						topStack.push(word)
						return topStack
					}
				}
			} else {return "There is no solution"}
		}
	} else {return "There is no solution"}
}

displayTable = function(){
	var table=document.getElementById("mytable");
	
	for (var i = table.rows.length - 1; i >= 0; i--) {
    	table.deleteRow(i);
	}	

	numOfLetters = document.getElementById("mydropdown").value
	startWord = document.getElementById("start").value
	endWord = document.getElementById("end").value
	if ((startWord.length == numOfLetters) && (endWord.length == numOfLetters)){	
		ladder = buildLadder(numOfLetters, startWord, endWord)
		if (ladder instanceof Stack){
			var i = ladder.length()
			while (i>0){
				var row=table.insertRow(-1);
				var cell1=row.insertCell(0);
				cell1.innerHTML= ladder.pop();
				i--
			}
		} else if (ladder == "There is no solution") { 
			alert("There is no path between these two words")
		}
	} else { alert("Type the right number of letters")}
}
