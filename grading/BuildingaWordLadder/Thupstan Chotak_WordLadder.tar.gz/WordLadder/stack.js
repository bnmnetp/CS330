Stack = function(){
	this.mystack = new Array()
}

Stack.prototype.push = function(x){
	this.mystack.push(x)
}

Stack.prototype.pop = function(){
	return this.mystack.pop()
}

Stack.prototype.peek = function(){
	return this.mystack[this.mystack.length-1]
}
Stack.prototype.deepcopy = function(){
	newStack = new Stack()
	for (x in this.mystack){
		newStack.push(this.mystack[x])
	}
	return newStack
}
Stack.prototype.length = function(){
	return this.mystack.length
}
