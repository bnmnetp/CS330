Queue = function(){
	this.myq = new Array()
}

Queue.prototype.enqueue = function(x){
	this.myq.push(x)
}

Queue.prototype.dequeue = function(){
	return this.myq.shift()
}

Queue.prototype.peek = function(){
	return this.myq[0]
}

Queue.prototype.isEmpty = function(){
	if (this.myq == []){
		return true
	} else return false
}

q = new Queue()
q.enqueue(5)
q.enqueue(6)
q.enqueue(7)
q.enqueue(8)
q.enqueue(9)
console.log(q.dequeue())
console.log(q.peek())
console.log(q)
console.log(q.isEmpty())
