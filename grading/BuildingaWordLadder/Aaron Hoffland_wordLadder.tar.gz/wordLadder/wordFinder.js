function Stack(){
	var mystack = new Array()
	
	this.push = function(e){
		mystack.push(e)
	}

	this.pop = function(){
		return mystack.pop()
	}
	this.peak = function(){
		var x = mystack.pop()
		mystack.push(x)
		mystack.push(x)
		return mystack.pop()
	}
	this.print = function(){
		return mystack.toString()
	}

	this.clone = function(){
		myclone = new Stack()
		for (var i = 0; i < mystack.length; i++){
			myclone.push(mystack[i])
		}
		return myclone

	}
	this.rev = function(){
		mystack.reverse()
	}
}

function Set(){
	var myset = new Array()
//has add and contains methods

	this.add = function(e){
		myset.push(e)
	}

	this.contains = function(tempstr){
		return myset.indexOf(tempstr) > -1
	}
	this.print = function(){
		return myset.toString()
	}

}

function Queue(){
	var myqueue = new Array()
	this.enqueue = function(e){
		myqueue.push(e)
	}

	this.dequeue = function(){
		return myqueue.shift()
	}
	this.print = function(){
		return myqueue.toString()
	}
	this.length = function(){
		return myqueue.length
	}
	this.finalPrint = function(){
		
	}
}


checkform = function(){
	var length = document.forms.todoform.wordLength.value
	var start = document.forms.todoform.start.value
	var end = document.forms.todoform.end.value

	return end.length == length && start.length == length

}
oneLetter = function(mypassedstack, myqueue, word, goal, len){
	var alph = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
	if (len == 3){
		//threeLetterWords
		var tempstr = ""

		
		for (i in alph){
			tempstr = alph[i] + word[1] + word[2]
			if ((threeLetterWords.indexOf(tempstr) > -1) && (!(usedWords.contains(tempstr)))){
				var tempstack = mypassedstack.clone()
				tempstack.push(tempstr)
				usedWords.add(tempstr)
				myqueue.enqueue(tempstack)

				
			}
			tempstr = word[0] + alph[i] + word[2]
			if ((threeLetterWords.indexOf(tempstr) > -1) && (!(usedWords.contains(tempstr)))){
				//need to push the old words onto the temp stack
				var tempstack = mypassedstack.clone()
				tempstack.push(tempstr)
				usedWords.add(tempstr)
				myqueue.enqueue(tempstack)


			}
			tempstr = word[0] + word[1] + alph[i]
			if ((threeLetterWords.indexOf(tempstr) > -1) && (!(usedWords.contains(tempstr)))){
				//need to push the old words onto the temp stack
				var tempstack = mypassedstack.clone()
				tempstack.push(tempstr)
				usedWords.add(tempstr)
				myqueue.enqueue(tempstack)

				
			}
		}
		

		for (var w = 0; w < myqueue.length(); w++){
			//alert("before")
			var mylocalstack = myqueue.dequeue()
			var myword = mylocalstack.peak()
			if (myword == goal){
				//found a path!
				mylocalstack.rev()
				return mylocalstack
			}
			else{
				return oneLetter(mylocalstack, myqueue, myword, goal, len)
			}
		}
	}
	else {
	if (len == 4){
		//fourLetterWords
		var tempstr = ""
		
		for (i in alph){
			tempstr = alph[i] + word[1] + word[2] + word[3]
			if ((fourLetterWords.indexOf(tempstr) > -1) && (!(usedWords.contains(tempstr)))){
				var tempstack = mypassedstack.clone()
				tempstack.push(tempstr)
				usedWords.add(tempstr)
				myqueue.enqueue(tempstack)

				
			}
			tempstr = word[0] + alph[i] + word[2] + word[3]
			if ((fourLetterWords.indexOf(tempstr) > -1) && (!(usedWords.contains(tempstr)))){
				//need to push the old words onto the temp stack
				var tempstack = mypassedstack.clone()
				tempstack.push(tempstr)
				usedWords.add(tempstr)
				myqueue.enqueue(tempstack)


			}
			tempstr = word[0] + word[1] + alph[i] + word[3]
			if ((fourLetterWords.indexOf(tempstr) > -1) && (!(usedWords.contains(tempstr)))){
				//need to push the old words onto the temp stack
				var tempstack = mypassedstack.clone()
				tempstack.push(tempstr)
				usedWords.add(tempstr)
				myqueue.enqueue(tempstack)

				
			}
			tempstr = word[0] + word[1] + word[2] + alph[i]
			if ((fourLetterWords.indexOf(tempstr) > -1) && (!(usedWords.contains(tempstr)))){
				//need to push the old words onto the temp stack
				var tempstack = mypassedstack.clone()
				tempstack.push(tempstr)
				usedWords.add(tempstr)
				myqueue.enqueue(tempstack)

				
			}
		}
		

		for (var w = 0; w < myqueue.length(); w++){
			var mylocalstack = myqueue.dequeue()
			var myword = mylocalstack.peak()
			if (myword == goal){
				//found a path!
				mylocalstack.rev()
				return mylocalstack
			}
			else{
				return oneLetter(mylocalstack, myqueue, myword, goal, len)
			}
		}
	}
	else {
		//fiveLetterWords
		var tempstr = ""

		
		for (i in alph){
			tempstr = alph[i] + word[1] + word[2] + word[3] + word[4]
			if ((fiveLetterWords.indexOf(tempstr) > -1) && (!(usedWords.contains(tempstr)))){
				var tempstack = mypassedstack.clone()
				tempstack.push(tempstr)
				usedWords.add(tempstr)
				myqueue.enqueue(tempstack)

				
			}
			tempstr = word[0] + alph[i] + word[2] + word[3] + word[4]
			if ((fiveLetterWords.indexOf(tempstr) > -1) && (!(usedWords.contains(tempstr)))){
				//need to push the old words onto the temp stack
				var tempstack = mypassedstack.clone()
				tempstack.push(tempstr)
				usedWords.add(tempstr)
				myqueue.enqueue(tempstack)


			}
			tempstr = word[0] + word[1] + alph[i] + word[3] + word[4]
			if ((fiveLetterWords.indexOf(tempstr) > -1) && (!(usedWords.contains(tempstr)))){
				//need to push the old words onto the temp stack
				var tempstack = mypassedstack.clone()
				tempstack.push(tempstr)
				usedWords.add(tempstr)
				myqueue.enqueue(tempstack)

				
			}
			tempstr = word[0] + word[1] + word[2] + alph[i] + word[4]
			if ((fiveLetterWords.indexOf(tempstr) > -1) && (!(usedWords.contains(tempstr)))){
				//need to push the old words onto the temp stack
				var tempstack = mypassedstack.clone()
				tempstack.push(tempstr)
				usedWords.add(tempstr)
				myqueue.enqueue(tempstack)

				
			}
			tempstr = word[0] + word[1] + word[2] + word[3] + alph[i]
			if ((fiveLetterWords.indexOf(tempstr) > -1) && (!(usedWords.contains(tempstr)))){
				//need to push the old words onto the temp stack
				var tempstack = mypassedstack.clone()
				tempstack.push(tempstr)
				usedWords.add(tempstr)
				myqueue.enqueue(tempstack)

				
			}
		}
		

		for (var w = 0; w < myqueue.length(); w++){
			var mylocalstack = myqueue.dequeue()
			var myword = mylocalstack.peak()
			if (myword == goal){
				//found a path!
				mylocalstack.rev()
				return mylocalstack
			}
			else{
				return oneLetter(mylocalstack, myqueue, myword, goal, len)
			}
		}
	}
	}

	return false
	
}
findPath = function(){
	var passed = checkform()
	var startQueue = new Queue()
	var startStack = new Stack()
	startStack.push(document.forms.todoform.start.value)
	usedWords = new Set()
	//alert(passed)
	if (!(passed)){
		alert("The words you entered are not equal length.")
		return false
	}
	usedWords.add(document.forms.todoform.start.value)
	//alert("Passed")
	//alert(usedWords)
	var path = ""
	path = oneLetter(startStack, startQueue, document.forms.todoform.start.value, document.forms.todoform.end.value, document.forms.todoform.wordLength.value)
	//alert(path.reverse())
	if (path != ""){
		//alert(path.print())// + "finally")
		
		var myTable =  document.getElementById("wordTable")
		
		while (path.peak() != undefined){
			var tr = document.createElement("tr")			
			myTable.appendChild(tr)
			//document.write(path.pop() + " ")
			var jump = path.pop()
			var td = document.createElement("td")
			//alert(jump)
			td.id = jump
			td.style.color = "blue"
			td.style.fontSize = "20px"
			tr.appendChild(td)
			var newTag = document.getElementById(jump)
			//alert(newTag)
			newTag.innerHTML = jump
		}
	}
	else {
		alert("No ladder was found for these words.")
	}
	alert("pause")
	//return True
}

/*
a = new Stack
a.push("a")
a.push("aa")
b = new Stack
b.push("b")
b.push("bb")
c = new Queue
c.enqueue(b)
c.enqueue(a)

*/
