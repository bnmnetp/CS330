Stack=function(){
   this.myStack = new Array()
}

Stack.prototype.push = function (x) {
   this.myStack.push(x)
}

Stack.prototype.pop = function () {
   return this.myStack.pop()
}

Stack.prototype.peek = function () {
   return this.myStack[(this.myStack.length)-1]
}

Stack.prototype.copy=function(){
   newStack = new Stack();
   var newstackarray = new Array()
   for(var i=0;i<this.myStack.length;i++){
      newstackarray.push(this.myStack[i])
   }
   newStack.myStack= newstackarray;
   return (newStack);
}
