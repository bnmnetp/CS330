wordladdergenerator = function(){
	first = document.myform.first.value
	last = document.myform.last.value
	selectedvalue = document.myform.lengthofword.value
	/*console.log(selectedvalue)
	console.log(first)
	console.log(last) **/
	var lengthofword1 = first.length;
	var lengthofword2 = last.length;
	/*console.log(lengthofword1)
	console.log(lengthofword2)**/

	if(lengthofword1 != lengthofword2){
		alert("Invalid Selection!! Please revise your selection and try again");
	}
	else if(first.length != selectedvalue){
		alert("Invalid Selection!! Please revise your selection and try again");
	}
	else{
		if(lengthofword1 ==3 && lengthofword2 ==3){
			dict =threeLetterWords;
			/**console.log(dict)**/
		}
		if(lengthofword1 ==4 && lengthofword2 ==4){
			dict =fourLetterWords;
			/**console.log(dict)**/
		}
		if(lengthofword1 ==5 && lengthofword2 ==5){
		        dict =fiveLetterWords;
			/**console.log(dict)**/
		}
		var soln = false;
		var done = false;

		myQueue = new Queue()
		myStack = new Stack()
		mySet = new Set()

		myStack.push(first)
		myQueue.enqueue(myStack)
		mySet.add(first)

		while (done == false && soln == false){
			stack = myQueue.dequeue()
			if (stack == undefined){
				done = true;
			}
			else{
				firststack = stack.pop()
				if (firststack == last){
					soln = true;
					stack.push(firststack)
					display(stack.myStack)
					alert(stack.myStack)
				}
				else{
					stack.push(firststack)
					for(i in dict){
						compare = dict[i]
						if (mySet.contains(compare) == false){
							diff = 0;
							//var x;
							for (var x =0; x<(compare.length+1); x++){
								if(compare[x] != firststack[x]){
									diff = diff+1;
								}
			                                }
							if(diff ==1){
								mySet.add(compare)
								copyStack = stack.copy();
								copyStack.push(compare);
								myQueue.enqueue(copyStack);

						}
	                                }
	                        }
	                }
	       }
	}
	}
}
display = function(array){
	var disp = document.createElement('h1')
	disp.innerhtml = 'Word Ladder'
	document.body.appendChild(disp)
}

