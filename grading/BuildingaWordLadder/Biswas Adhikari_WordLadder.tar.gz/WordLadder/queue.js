Queue = function(){
	this.myQueue = new Array()
}

Queue.prototype.peek = function(){
	return this.myQueue[0]
}

Queue.prototype.isEmpty = function(){
	if (this.myQueue == []){
		return true
	} else return false
}

Queue.prototype.enqueue = function(x){
	this.myQueue.push(x)
}

Queue.prototype.dequeue = function(){
	return this.myQueue.shift()
}
