buildColor = function(){
	return"rgb(" + Math.floor(Math.random()*256) + ", " + Math.floor(Math.random()*256) + ", " + Math.floor(Math.random()*256) + ")"
}

clock = function(myctx){
	
	//ctx.fillStyle = 'red'
	ctx.strokeStyle = buildColor()
	//ctx.strokeRect(50,25,200,100)
	
	var offsetx = Math.floor(Math.random()*500)
	var offsety = Math.floor(Math.random()*400)

	ctx.beginPath()
	ctx.moveTo(offsetx, 50 + offsety)
	ctx.lineTo(30 + offsetx, 10 + offsety)
	ctx.lineTo(50 + offsetx, 50 + offsety)
	ctx.lineTo(40 + offsetx, 30 + offsety)
	ctx.lineTo(15 + offsetx, 30 + offsety)	
	ctx.stroke()
	ctx.closePath()
	ctx.moveTo(80 + offsetx, 50 + offsety)
	ctx.lineTo(80 + offsetx, 10 + offsety)
	ctx.lineTo(110 + offsetx, 10 + offsety)
	ctx.lineTo(110 + offsetx, 30 + offsety)
	ctx.lineTo(80 + offsetx, 30 + offsety)
	ctx.stroke()
	ctx.closePath()
	ctx.moveTo(140 + offsetx,10 + offsety)
	ctx.lineTo(140 + offsetx, 50 + offsety)
	ctx.lineTo(140 + offsetx, 30 + offsety)
	ctx.lineTo(170 + offsetx, 30 + offsety)
	ctx.lineTo(170 + offsetx, 10 + offsety)
	ctx.lineTo(170 + offsetx, 50 + offsety)
	ctx.stroke()
	//
  }
  
drawNorse = function(myctx){
	var x = Math.floor(Math.random()*600)
	var y = Math.floor(Math.random()*400)
	var img=document.getElementById("norse")
	myctx.drawImage(img,x,y, 25, 20)//,width,height)
	//myctx.rotate(x)
}

drawit = function(start) {
	
	if (start){
	canvas = document.getElementById('mycanvas')
	ctx = canvas.getContext("2d")
	clo=self.setInterval("clock(ctx)",1000);
	nor=self.setInterval("drawNorse(ctx)",1000);
	eraserOff = true
	//ctx.rotate(20*Math.PI/180)
	}
	
	//ctx.lineTo(235,83)
	//ctx.moveTo(500,500)
	//ctx.bezierCurveTo(175, 120, 115, 233, 450, 125)
	//ctx.bezierCurveTo(375, 354, 543, 12, 45, 786)
	//ctx.bezierCurveTo(10, 652, 33, 456, 350, 350)
	//ctx.stroke()
	else{
		self.clearInterval(clo)
		self.clearInterval(nor)
	}
}

stopDraw = function(){

	drawit(false)
}
rotateCanvas = function(){
	ctx.rotate(20*Math.PI/180)
}

writeSomething = function(){
	var x = Math.floor(Math.random()*500)
	var y = Math.floor(Math.random()*400)
	var theirStuff = document.getElementById("toWrite").value
	ctx.fillText(theirStuff,x,y);
}
eraser = function(e){
	//alert( + ' Y=' + )
	//alert("eraser is " + eraserOff)
	var size = document.getElementById("eraserSize").value
	//alert(size)
	if (!(eraserOff)){
		//alert("ERASING")
		//ctx.fillStyle = 'white'
		ctx.clearRect(window.event.pageX - canvas.offsetLeft - size/2,window.event.pageY - canvas.offsetTop - size/2,size,size);
	}
}
toggleEraser = function(){
	eraserOff = !(eraserOff)
	//alert(eraserOff)
}