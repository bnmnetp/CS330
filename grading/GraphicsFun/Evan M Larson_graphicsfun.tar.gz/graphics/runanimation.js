drawObjects = function() {
	canvas = document.getElementById("mycanvas")
	canvas.width = canvas.width
	ball.freeFall()
	if (lives == 0) {
		killAnimation(anim)
		alert("You lose")
	}
	for (var i=0; i<brickArray.length;i++) {
		brick = brickArray[i]
		brick.draw()
		if(brick.detectCollision(ball)) {
			brickArray.splice(i,1)
			if (brickArray.length == 0) {
				killAnimation(anim)
				alert("You win")
			}
		}
	}
	paddle.draw()
	if (paddle.detectCollision(ball)) {
		console.log("bounce!")
	}
}

collision = function(ball1,ball2) {
	//May just change this to work for bricks only. We'll see. Probably should talk to Jon about it.
	if (ball1.detectCollision(ball2)) {
		console.log("Collision occurred")
		//Get Ball1's velocities
		ball1Vel = ball1.getVelocity()
		v1x = ball1Vel[0]
		v1y = ball1Vel[1]

		//Get Ball2's velocities
		ball2Vel = ball2.getVelocity()
		v2x = ball2Vel[0]
		v2y = ball2Vel[1]

		ball1.setVelocity(v2x,v2y)
		ball2.setVelocity(v1x,v1y)
	}
}

anim = self.setInterval("drawObjects()",25)

killAnimation = function(id) {
	console.log("Kill called")
	id = window.clearInterval(id)
}

