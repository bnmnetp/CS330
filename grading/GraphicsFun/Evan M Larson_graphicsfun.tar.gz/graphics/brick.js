//Brick class. Used in break out.

Brick = function(x,y) {
	var xpos = x
	var ypos = y

	var sideCollision = false;

	var leftXbound = x
	var rightXbound = x + 50
	var upperYbound = y
	var lowerYbound = y + 10

	this.draw = function() {
		//Step 1: Get Canvas
		canvas = document.getElementById("mycanvas")

		//Step 2: Get Graphics Context (can only do 2d)
		ctx = canvas.getContext("2d")
		ctx.lineWidth = 5

		//Step 3: Set Fill/Stroke Style and Fill/Stroke Object (fill/stroke must match for properties like color to be applied.
		ctx.fillStyle = "black"
		ctx.fillRect(xpos,ypos,50,10) //format is ctx.fillRect(x,y,width,height)
	}

	this.detectCollision = function(ball) {
		//bounds of "this" ball
		ballLocation = ball.getPosition()
		ballX = ballLocation[0]
		ballY = ballLocation[1]
		if (ballX <= rightXbound && ballX >= leftXbound && ballY <= lowerYbound && ballY >= upperYbound) {
			if ((ballX == rightXbound && ballY <= lowerYbound && ballY >= upperYbound) || (ballX == leftXbound && ballY <= lowerYbound && ballY >= upperYbound)) {
				console.log("ball hit a brick on the side")
				ball.brickSideCollision()
				return true;
			}
			ball.brickTopBottomCollision()
			return true;
		}
		else {
			return false;
		}
	}
}
