//ClickTracker object is to help with making it so that the user will click and flick to give the ball a new velocity


ClickTracker = function() {
	var firstx;
	var secondx;

	var firsty;
	var secondy;

	var timeElapsed;

	this.setFirstClick = function(x,y) {
		firstx = x;
		firsty = y
	}

	this.setSecondClick = function(x,y) {
		secondx = x;
		secondy = y;
	}

	this.setTimeElapsed = function(time) {
		timeElapsed = time;
	}

	this.calculateNewXVelocity = function() {
		console.log("Calc x function called")
		newX = ((secondx - firstx) / (timeElapsed*3))
		console.log(newX)
		return newX
	}

	this.calculateNewYVelocity = function() {
		newY = ((secondy - firsty) / (timeElapsed*3))
		console.log(newY)
		return newY
	}



}
