//Declares ball function. That has properties like location?, size, color, etc

Ball = function(startX,startY) {
	var mass = 2;
	radius = 5;
	//var color = "red";
	var newVelocitySet = false; //used to determine whether or not the ball should start moving again after the user flicks the mouse

	//Values needed to perform physics operations.
		var initX = startX;
		var initY = startY;

		var xpos = 0;
		var ypos = 0;
		var time = 0;
		var yV0 = 0;
		var yVel = 0;
		var xVel = 15;
		var gravity = 9.8;

	this.draw = function(xpos,ypos) {
		//8,68 appears to be the top left corner;
		//console.log("Ball was drawn");
		canvas = document.getElementById("mycanvas");
		ctx = canvas.getContext("2d");
		ctx.fillStyle="#FF0000";
		ctx.moveTo(xpos-8,ypos-68);
		ctx.beginPath();
		ctx.arc(xpos-8,ypos-68,5,0,Math.PI*2,true);
		ctx.closePath();
		ctx.fill();
	}

	this.getVelocity = function() {
		return new Array(xVel,yVel);
	}

	this.setVelocity = function(x,y) {
		xVel = x;
		yV0 = y;
		newVelocitySet = true;
	}

	this.freeFall = function() {
		if (yVel <= .00005 && ypos >= 412 && !newVelocitySet) {
			//console.log("ball has stopped");
		}
		else {
			//console.log("And I'm FRRRREEEEEE. Free Fallin");
			time = time + .100;

			xpos = initX + xVel*time;
			ypos = initY + yV0*time + .5*gravity*(time*time);

			yVel = yV0 + gravity*(time);

			if (xpos <= 13 || xpos >= 500) {
				this.sideCollision();
			}
			if (ypos <= 73 || ypos >= 412) {
				this.topBottomcollision();
			}

			this.draw(xpos,ypos);
			newVelocitySet = false;
		}
	}

	//Top and bottom dimensions: Top: y <= 73 Bottom: y >= 412
	this.topBottomcollision = function() {
		//console.log("Ball hit the bottom or the top of the screen")
		yV0 = yVel*(-1);

		if (ypos >= 412) {
			initY = 412;
			ballLost()
		}
		else {
			initY = 73;
		}
		initX = xpos;
		//initY = ypos;

		time = 0;
	}

	//Left and Right Dimensions: Left: x <= 13 Right: x >= 500
	this.sideCollision = function() {
		console.log("Ball hit one of the sides");
		yV0 = yVel;
		xVel = xVel*(-1);

		if (xpos >=500) { //Should help keep the ball from disappearing from the canvas
			initX = 500;
		}
		else {
			initX = 13;
		}

		//initX = xpos;
		initY = ypos;

		time = 0;
	}

	this.getPosition = function() {
		return new Array(xpos-8,ypos-68);
	}

	this.brickTopBottomCollision = function() {
		//console.log("ball hit a brick");
		yV0 = yVel*(-1);

		initX = xpos;
		initY = ypos;

		time = 0;
	}

	this.brickSideCollision = function() {
		yV0 = yVel;
		xVel = xVel*(-1);

		initX = xpos;
		initY = ypos;

		time = 0;
	}

	this.paddleCollision = function() {
		yV0 = yVel*(-1.01);

		initX = xpos;
		initY = ypos;

		time = 0;
	}
}

