timer = new Timer()
ct = new ClickTracker()

paddle = new Paddle(250,320)

ball = new Ball(150,275)
ball.setVelocity(10,10)

brickArray = new Array()
for (var i=0; i < 6; i++) {
	for (var j=0; j < 6; j++) {
		xpos = 75 + 60*j
		ypos = 75 + 20*i
		brick = new Brick(xpos,ypos)
		brickArray.push(brick)
	}
}

lives = 3;

ballLost = function() {
	lives--;
	numLives = document.getElementById("lives")
	if (lives == 1) {
		numLives.innerHTML = lives + " life.";
	}
	else {
		numLives.innerHTML = lives + " lives.";
	}
	ball = new Ball(150,275)
	ball.setVelocity(10,10)
}
