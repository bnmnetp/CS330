//Object used for calculating physics type things based on values like x and y velocity and time. This info is then used to draw our ball.

PhysicsMachine = function() {
	var xV0 = 0;
	var yV0 = -12;
	ball = new Ball()

	var xVel = 0;
	var yVel = 0;

	var gravity = 9.8 // M/S^2 aka pixels/seconds^2 (want this to be aimed down, so will technically be positive (increasing y)
	var time = 0;

	var xpos = 0;
	var ypos = 0;

	var initX = 100;
	var initY = 100;

	this.setStartPos = function(x,y) {
		initX = x
		initY = y
	}

	this.setPosition = function(xcord,ycord) {
		xpos = xcord
		ypos = ycord
	}

	//Do as snap shots so a start pos/velocity isn't needed?

	this.freeFall = function() {
		if (yVel <= .005 && ypos >= 412) {
			console.log("ball has stopped")
		}
		else {
			//console.log("And I'm FRRRREEEEEE. Free Fallin")
			time = time + .100

			xpos = initX + xV0*time
			ypos = initY + yV0*time + .5*gravity*(time*time)

			if (xpos <= 13 || xpos >= 500) {
				this.sideCollision()
			}
			if (ypos <= 73 || ypos >= 412) {
				this.topBottomcollision()
			}

			ball.draw(xpos,ypos)

			yVel = yV0 + gravity*(time)
		}
	}

	//Top and bottom dimensions: Top: y <= 73 Bottom: y >= 412
	this.topBottomcollision = function() {
		//console.log("Ball hit the bottom or the top of the screen")
		yV0 = yVel*(-.5)
		xV0 = xVel*(.9)

		initX = xpos
		initY = ypos

		time = 0
	}

	//Left and Right Dimensions: Left: x <= 13 Right: x >= 500
	this.sideCollision = function() {
		yV0 = yVel*(.9)
		xV0 = xVel*(-.5)

		initX = xpos
		initY = ypos

		time = 0
	}

	this.getXPos = function() {
		return xpos
	}

	this.getYPos = function() {
		return ypos
	}
}
