//Mouse events code.

startClick = function(evt) {
	x = evt.x
	y = evt.y
	timer.startTimer()
	ct.setFirstClick(x,y)
	//console.log("Starting X Location was: " + x)
	//console.log("Starting Y Location was: " +y)
}

endClick = function(evt) {
	x = evt.x
	y = evt.y
	timer.stopTimer()
	ct.setSecondClick(x,y)
	ct.setTimeElapsed(timer.timeElapsed())
	xVel = ct.calculateNewXVelocity()
	if (xVel != 0) {
		ball.setVelocity(xVel,ct.calculateNewYVelocity())
	}
	//console.log("Ending X Location was: " + x)
	//console.log("Ending Y Location was: " + y)
	//console.log("Click lasted for " + timer.timeElapsed())
}

movePaddle = function(evt) {
	x = evt.x - 8
	//console.log(x)
	paddle.setPosition(x)
}
