# Echo client program
import socket

HOST = ''    # The remote host
PORT = 50007              # The same port as used by the server
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))

estring = raw_input("-> ")
while estring.lower() != "exit":
    s.send(estring)
    data = s.recv(1024)
    print "result = ", data
    estring = raw_input("-> ")
    
s.close()

print 'Received', data

