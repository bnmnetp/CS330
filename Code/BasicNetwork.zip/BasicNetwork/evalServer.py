# Echo server program
import socket

# Define a simple function to eval whatever string the user sends across
def processRecvd(s):
    s = str(s).strip()
    print "got :", s, ":"
    try:
        x = eval(s)
    except:
        x = "Could not eval " + s
    return str(x) + "\n"
    
HOST = ''                 # Symbolic name meaning the local host
PORT = 50007              # Arbitrary non-privileged port
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
s.listen(1)
conn, addr = s.accept()
print 'Connected by', addr

data = conn.recv(1024)
while data:
    conn.send(processRecvd(data))
    data = conn.recv(1024)

conn.close()

