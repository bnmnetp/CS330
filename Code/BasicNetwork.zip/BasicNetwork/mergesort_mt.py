# Echo server program
import socket
from threading import Thread
import random
import time

class Sorter(Thread):
    def __init__(self, numList):
        super(Sorter, self).__init__()
        self.alist = numList
        
    def run(self):
        """docstring for run"""
        for index in range(1,len(self.alist)):

            currentvalue = self.alist[index]
            position = index

            while position>0 and self.alist[position-1]>currentvalue:
                self.alist[position]=self.alist[position-1]
                position = position-1

            self.alist[position]=currentvalue


def insertionSort(alist):
   for index in range(1,len(alist)):

     currentvalue = alist[index]
     position = index

     while position>0 and alist[position-1]>currentvalue:
         alist[position]=alist[position-1]
         position = position-1

     alist[position]=currentvalue

def mergeSort(alist):
    if len(alist)>1:
        mid = len(alist)//2
        lefthalf = alist[:mid]
        righthalf = alist[mid:]

        # start two threads to sort each half
        start = time.time()
        # lh = Sorter(lefthalf)
        # rh = Sorter(righthalf)
        # lh.start()
        # rh.start()
        # lh.join()
        # rh.join()
        # lefthalf = lh.alist
        # righthalf = rh.alist
        insertionSort(lefthalf)
        insertionSort(righthalf)
        i=0
        j=0
        k=0
        while i<len(lefthalf) and j<len(righthalf):
            if lefthalf[i]<righthalf[j]:
                alist[k]=lefthalf[i]
                i=i+1
            else:
                alist[k]=righthalf[j]
                j=j+1
            k=k+1

        while i<len(lefthalf):
            alist[k]=lefthalf[i]
            i=i+1
            k=k+1

        while j<len(righthalf):
            alist[k]=righthalf[j]
            j=j+1
            k=k+1
    end = time.time()
    print 'sort time = ', end-start
    print("Merged ")


sl = [random.randrange(10000) for i in range(10000)]
mergeSort(sl)



