# Echo server program

from multiprocessing import Process, Queue, Array
import random
import time

def insertionSortSP(alist):
   for index in range(1,len(alist)):

        currentvalue = alist[index]
        position = index

        while position>0 and alist[position-1]>currentvalue:
            alist[position]=alist[position-1]
            position = position-1

        alist[position]=currentvalue

def insertionSort(alist,q):
   for index in range(1,len(alist)):

        currentvalue = alist[index]
        position = index

        while position>0 and alist[position-1]>currentvalue:
            alist[position]=alist[position-1]
            position = position-1

        alist[position]=currentvalue
   q.put(alist)

def mergeSort(alist):
    if len(alist)>1:
        mid = len(alist)//2
        lefthalf = alist[:mid]
        righthalf = alist[mid:]

        # start two threads to sort each half
        if len(lefthalf) <= 10000:
            lhq = Queue()
            rhq = Queue()        
            lh = Process(target=insertionSort,args=(lefthalf,lhq))
            rh = Process(target=insertionSort,args=(righthalf,rhq))
            lh.start()
            rh.start()
            lefthalf = lhq.get()
            righthalf = rhq.get()
            lh.join()
            rh.join()
            # insertionSortSP(lefthalf)
            # insertionSortSP(righthalf)
        else:
            mergeSort(lefthalf)
            mergeSort(righthalf)
        i=0
        j=0
        k=0
        while i<len(lefthalf) and j<len(righthalf):
            if lefthalf[i]<righthalf[j]:
                alist[k]=lefthalf[i]
                i=i+1
            else:
                alist[k]=righthalf[j]
                j=j+1
            k=k+1

        while i<len(lefthalf):
            alist[k]=lefthalf[i]
            i=i+1
            k=k+1

        while j<len(righthalf):
            alist[k]=righthalf[j]
            j=j+1
            k=k+1




sl = [random.randrange(10000) for i in range(20000)]
start = time.time()
mergeSort(sl)
end = time.time()
print 'sort time = ', end-start

